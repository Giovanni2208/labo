﻿using Comptabilite.Api.models.Command;
using Comptabilite.Api.models.Querries; 
using Tools1.Cqs.Command;
using Tools1.Cqs.Querries;

namespace Api.Models.Repositories
{
    public interface IAuthRepository :
        ICommandHandler<CommandRegister>, IQueryHandler<LoginQuery, Utilisateur?>
    {
        ICommandResult Execute(CommandRegister command);
        Utilisateur? Execute(LoginQuery query);
    }
}