﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tools1.Cqs.Querries;

namespace Comptabilite.Api.models.Querries
{
    public class LoginQuery : IQueryDefinition<Utilisateur>
    {
        public LoginQuery(string email, string passwd)
        {
            Email = email;
            Passwd = passwd;
        }

        public string Email { get; init; }
        public string Passwd { get; init; }
    }
}
