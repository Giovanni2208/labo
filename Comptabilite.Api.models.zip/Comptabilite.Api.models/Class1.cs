﻿namespace Comptabilite.Api.models
{
    public class Class1
    {

    }
}