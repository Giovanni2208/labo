﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Comptabilite.Api.models.Mappers
{
    internal static class Mappers
    {
        internal static Utilisateur ToUtilisateur(this IDataRecord record)
        {
            //Taduit un record DB en un utilisateur
            return new Utilisateur(
                    (int)record["Id"],
                    (string)record["Nom"],
                    (string)record["Prenom"],
                    (string)record["Email"]
                );
        }
    }
}
