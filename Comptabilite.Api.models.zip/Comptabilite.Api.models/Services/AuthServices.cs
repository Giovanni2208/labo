﻿using Api.Models.Repositories;
using ApplicationComptable;
using Comptabilite.Api.models.Command;
using Comptabilite.Api.models.Mappers;
using Comptabilite.Api.models.Querries; 
using System.Data;
using System.Data.Common;
using Tools1.Cqs.Command;

namespace Api.Models.Services
{
    public class AuthServices : IAuthRepository

    {
        private readonly DbConnection _dbConnection;

        public AuthServices(DbConnection dbConnection)
        {
            _dbConnection = dbConnection;
        }
        public ICommandResult Execute(CommandRegister command)
        {
            try
            {
                using (_dbConnection)
                {
                    _dbConnection.Open();
                    _dbConnection.ExecuteNonQuery("Register", true, command);
                    return ICommandResult.Success();
                }
            }
            catch (Exception ex) 
            {
                return ICommandResult.Failure(ex.Message);
            }
        }

        public Utilisateur? Execute(LoginQuery query)
        {
            if (_dbConnection.State is not ConnectionState.Open) _dbConnection.Open();

            Utilisateur? utilisateur = _dbConnection.ExecuteReader("SP_Login", (r) => r.ToUtilisateur(),true, query).SingleOrDefault();

            _dbConnection.Close();
            return utilisateur;
        }
    }
}
