﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Comptabilite.Api.models.Entities
{
    public class Facture
    {

    internal Facture(int id, int  dateFacture,int clientId)
    {
            Id = id;
            DateFacture = dateFacture;
            ClientId = clientId;

    }
        public int Id { get; set; }
        public int DateFacture { get; set;}
        public int ClientId { get; set;}
    } 
}
