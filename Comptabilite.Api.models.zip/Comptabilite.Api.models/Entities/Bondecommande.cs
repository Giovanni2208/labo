﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Comptabilite.Api.models.Entities
{
    public class Bondecommande
    {

    internal Bondecommande(int id,DateTime datecommande,int clientid)
    {
            Id = id;
            DateCommande = datecommande;
            Clientid = clientid;
    }
        public int Id { get; set; }
        public DateTime DateCommande { get; set; }
        public int Clientid { get; set; }
    }
}
