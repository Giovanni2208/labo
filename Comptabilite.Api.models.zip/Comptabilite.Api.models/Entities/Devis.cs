﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Comptabilite.Api.models.Entities
{
    public class Devis
    {

      internal Devis(int id, DateTime datedevis, int clientid)
    {
            Id = id;
            DateDevis = datedevis;
            Clientid = clientid;
        }
        public int Id { get; set; }
        public DateTime DateDevis { get; set; }
        public int Clientid { get; set; }
    }
}
