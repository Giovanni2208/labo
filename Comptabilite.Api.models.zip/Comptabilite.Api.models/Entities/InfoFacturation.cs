﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Comptabilite.Api.models.Entities
{
    public class InfoFacturation
    {

        internal InfoFacturation(string nom, string adresse, int codepostal, int tel, string email, int tva)
        {
            Nom = nom;
            Adresse = adresse;
            CodePostal = codepostal;
            Tel = tel;
            Email = email;
            TVA = tva;

        }
        public string Nom { get; set; }
        public string Adresse { get; set; }
        public int CodePostal { get; set; }
        public int Tel { get; set; }
        public string Email { get; set; }
        public int TVA { get; set; }
    }
}

