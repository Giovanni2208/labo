﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Comptabilite.Api.models.Entities
{
    public class Client
    {

        internal Client(int id, string nom, string prenom, string societe,string adresse, int codepostal,int tva,int tel, string email)
        {

            ID = id;
            Nom = nom;
            Prenom = prenom;
            Societe = societe;
            Adresse = adresse;
            CodePostal = codepostal;
            TVA = tva;
            Telephone = tel;
            Email = email;
        }

        public int ID { get; set; }
        public string Nom { get; init; }
        public string Prenom { get; init; }
        public string Societe { get; init; }
        public string Adresse { get; init; }
        public int CodePostal { get; init; }
        public int TVA { get; init; }
        public int Telephone { get; init; }
        public string Email { get; init; }
        
    }
}
